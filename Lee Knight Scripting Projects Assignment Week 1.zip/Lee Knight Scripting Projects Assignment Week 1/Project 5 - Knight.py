Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  6 2021, 13:40:21) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> base = int(input("Enter with base: "))
Enter with base: 5
>>> height = int(input("Enter with height: "))
Enter with height: 7
>>> area = base * height * .5
>>> print("The area is" , area , "square units. ")
The area is 17.5 square units. 
>>> 
>>> 
>>> base = int(input("Enter with base: "))
Enter with base: 6
>>> height = int(input("Enter with height: "))
Enter with height: 5
>>> area = base * height * .5
>>> print("The area is" , area , "square units. ")
The area is 15.0 square units. 
>>> 
>>> 
>>> base = int(input("Enter with base: "))
Enter with base: 10
>>> height = int(input("Enter with height: "))
Enter with height: 10
>>> area = base * height * .5
>>> print("The area is" , area , "square units. ")
The area is 50.0 square units. 
>>> 