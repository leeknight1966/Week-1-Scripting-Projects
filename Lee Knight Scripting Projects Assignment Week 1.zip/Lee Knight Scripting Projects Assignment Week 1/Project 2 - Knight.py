Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  6 2021, 13:40:21) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> name = ("Lee Knight")
>>> address = ("3582 E Fjord Pony Road Tucson, Arizona 85739")
>>> telephone = ("(520)403-5714")
>>> print(name, address, telephone)
Lee Knight 3582 E Fjord Pony Road Tucson, Arizona 85739 (520)403-5714
>>> 