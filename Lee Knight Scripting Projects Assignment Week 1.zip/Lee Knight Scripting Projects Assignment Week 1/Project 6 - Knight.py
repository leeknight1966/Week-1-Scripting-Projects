Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  6 2021, 13:40:21) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> Pi = 3.14
>>> radius = 7
>>> area = Pi * radius ** 2
>>> print("The area of the circle is" , area)
The area of the circle is 153.86
>>> 
>>> 
>>> 
>>> Pi = 3.14
>>> radius = 6.31
>>> area = Pi * radius ** 2
>>> print("The area of the circle is" , area)
The area of the circle is 125.02255399999999
>>> 
>>> 
>>> Pi = 3.14
>>> radius = 14.96
>>> area = Pi * radius ** 2
>>> print("The area of the circle is" , area)
The area of the circle is 702.7370240000001
>>> 