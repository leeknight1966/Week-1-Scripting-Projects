Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  6 2021, 13:40:21) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> width = int(input("Enter with width: "))
Enter with width: 3
>>> length = int(input("Enter with length: "))
Enter with length: 10
>>> area = width * length
>>> print("The area is" , area , "square units")
The area is 30 square units
>>> 
>>> 
>>> width = int(input("Enter with width: "))
Enter with width: 13
>>> length = int(input("Enter with length: "))
Enter with length: 7
>>> area = width * length
>>> print("The area is" , area , "square units")
The area is 91 square units
>>> 
>>> 
>>> width = int(input("Enter with width: "))
Enter with width: 6
>>> length = int(input("Enter with length: "))
Enter with length: 6
>>> area = width * length
>>> print("The area is" , area , "square units")
The area is 36 square units
>>> 